"""
Unit and Integration Tests for University Regulation RAG Assistant.

Tests:
1. Sample PDF generation and page validation
2. Document loading & text preprocessing (metadata preservation)
3. Recursive character chunking & boundary overlap
4. Dense vector embeddings & L2 normalization
5. Vector store similarity search (FAISS / NumPy)
6. Metadata pre-filtering
7. Grounded answer generation with page citations
8. Hallucination reduction: out-of-domain query refusal
"""

import os
import sys
import unittest
import numpy as np

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.generate_sample_pdfs import create_sample_pdfs
from rag.document_loader import load_multiple_pdfs, load_pdf_from_path, preprocess_text
from rag.chunker import RecursiveCharacterChunker
from rag.embeddings import LocalDenseEmbeddingEngine
from rag.vector_store import UniversityVectorStore
from rag.retriever import UniversityRetriever
from rag.generator import LocalGroundedGenerator, REFUSAL_MESSAGE


class TestUniversityRAG(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sample_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "samples")
        create_sample_pdfs(cls.sample_dir)

        # Load sample PDFs
        pdf_paths = [
            os.path.join(cls.sample_dir, f)
            for f in sorted(os.listdir(cls.sample_dir))
            if f.endswith(".pdf")
        ]
        cls.pages = load_multiple_pdfs(pdf_paths)

        # Chunk pages (default 600 chars, 100 overlap)
        cls.chunker = RecursiveCharacterChunker(chunk_size=600, chunk_overlap=100)
        cls.chunks = cls.chunker.chunk_pages(cls.pages)

        # Embeddings & Vector Store
        cls.embedder = LocalDenseEmbeddingEngine()
        texts = [c.content for c in cls.chunks]
        cls.embeddings = cls.embedder.embed_documents(texts)

        cls.vstore = UniversityVectorStore(store_type="FAISS")
        cls.vstore.add_chunks(cls.chunks, cls.embeddings)

        cls.retriever = UniversityRetriever(
            vector_store=cls.vstore,
            embedding_engine=cls.embedder,
            default_top_k=4,
            min_similarity_threshold=0.25
        )
        cls.generator = LocalGroundedGenerator()

    def test_01_sample_pdfs_generated(self):
        """Ensure all 4 expected PDF regulation documents exist."""
        expected_files = [
            "Academic_Regulations_2026.pdf",
            "Attendance_Policy.pdf",
            "Examination_Guidelines.pdf",
            "Student_Code_of_Conduct.pdf"
        ]
        existing = os.listdir(self.sample_dir)
        for ef in expected_files:
            self.assertIn(ef, existing, f"Expected {ef} to be generated.")

    def test_02_document_loading_and_metadata(self):
        """Ensure pages are extracted with correct 1-indexed page numbers and categories."""
        self.assertGreater(len(self.pages), 8, "Expected at least 9 pages across 4 documents.")

        attendance_pages = [p for p in self.pages if "Attendance_Policy" in p.source]
        self.assertEqual(len(attendance_pages), 3, "Attendance Policy should have exactly 3 pages.")
        self.assertEqual([p.page_number for p in attendance_pages], [1, 2, 3])
        self.assertEqual(attendance_pages[0].category, "Attendance Policy")

    def test_03_chunking_and_overlap(self):
        """Ensure chunk size limits and metadata retention."""
        self.assertGreater(len(self.chunks), len(self.pages))
        for chunk in self.chunks:
            self.assertLessEqual(chunk.char_count, 650, "Chunk exceeded max size limit.")
            self.assertTrue(chunk.source.endswith(".pdf"))
            self.assertGreaterEqual(chunk.page, 1)
            self.assertTrue(chunk.chunk_id.startswith(chunk.source))

    def test_04_embeddings_normalization(self):
        """Ensure embedding vectors are unit normalized (L2 norm == 1.0)."""
        norms = np.linalg.norm(self.embeddings, axis=1)
        np.testing.assert_allclose(norms, 1.0, rtol=1e-4, err_msg="Embeddings must be L2 unit vectors.")

    def test_05_grounded_retrieval(self):
        """Query for attendance rules and verify correct document and page are retrieved."""
        query = "What is the minimum attendance required for exam eligibility?"
        result = self.retriever.retrieve(query, top_k=3)

        self.assertTrue(result.has_grounded_context)
        self.assertGreater(len(result.chunks), 0)

        top_chunk, score = result.chunks[0]
        self.assertEqual(top_chunk.source, "Attendance_Policy.pdf")
        self.assertEqual(top_chunk.page, 1)
        self.assertIn("75%", top_chunk.content)
        self.assertGreaterEqual(score, 0.30)

    def test_06_metadata_filtering(self):
        """Verify that pre-filtering restricts vector search to the specified category."""
        query = "What are the rules and penalties for exam malpractice?"

        # Search with matching category
        res_conduct = self.retriever.retrieve(
            query,
            metadata_filter={"category": "Student Conduct & Handbook"}
        )
        self.assertTrue(res_conduct.has_grounded_context)
        for c, _ in res_conduct.chunks:
            self.assertEqual(c.category, "Student Conduct & Handbook")

        # Search with conflicting category (Attendance) should return no matching malpractice chunks
        res_attendance = self.retriever.retrieve(
            query,
            metadata_filter={"category": "Attendance Policy"}
        )
        for c, _ in res_attendance.chunks:
            self.assertEqual(c.category, "Attendance Policy")

    def test_07_hallucination_refusal(self):
        """Verify that out-of-domain queries are rejected with the standard refusal message."""
        out_of_domain_query = "What is the recipe for chocolate lava cake with strawberry icing?"
        result = self.retriever.retrieve(out_of_domain_query, custom_threshold=0.35)

        gen_output = self.generator.generate(result)
        self.assertFalse(gen_output["is_grounded"])
        self.assertEqual(gen_output["answer"], REFUSAL_MESSAGE)

    def test_08_grounded_generation_with_citations(self):
        """Verify that a valid regulation question generates an answer with citations."""
        query = "How much is the fee for attendance condonation?"
        result = self.retriever.retrieve(query)
        gen_output = self.generator.generate(result)

        self.assertTrue(gen_output["is_grounded"])
        self.assertIn("$40", gen_output["answer"])
        citations = gen_output["citations"]
        self.assertGreater(len(citations), 0)
        self.assertTrue(any(c["source"] == "Attendance_Policy.pdf" and c["page"] == 2 for c in citations))


if __name__ == "__main__":
    unittest.main()
