"""
Sample PDF Generator for University Regulation RAG.

Generates 4 realistic, official university regulation PDF documents:
1. Academic_Regulations_2026.pdf
2. Attendance_Policy.pdf
3. Examination_Guidelines.pdf
4. Student_Code_of_Conduct.pdf

Uses reportlab to create structured, multi-page PDFs with headers, section titles,
page numbers, and authentic university rules.
"""

import os
import sys

def create_sample_pdfs(output_dir: str = "data/samples"):
    os.makedirs(output_dir, exist_ok=True)
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.pdfgen import canvas
    except ImportError:
        print("[ERROR] reportlab is required to generate PDFs. Please run after reportlab is installed.")
        return

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#1E3A8A'),
        alignment=1, # Center
        spaceAfter=14
    )
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontSize=11,
        leading=14,
        textColor=colors.HexColor('#4B5563'),
        alignment=1,
        spaceAfter=20
    )
    h1_style = ParagraphStyle(
        'SectionH1',
        parent=styles['Heading2'],
        fontSize=14,
        leading=18,
        textColor=colors.HexColor('#1E40AF'),
        spaceBefore=14,
        spaceAfter=8
    )
    body_style = ParagraphStyle(
        'BodyDark',
        parent=styles['BodyText'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=10
    )
    bullet_style = ParagraphStyle(
        'BulletDark',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#1F2937'),
        leftIndent=15,
        spaceAfter=6
    )

    class NumberedCanvas(canvas.Canvas):
        """Adds running footer with page numbers."""
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._saved_page_states = []

        def showPage(self):
            self._saved_page_states.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            num_pages = len(self._saved_page_states)
            for state in self._saved_page_states:
                self.__dict__.update(state)
                self.draw_footer(num_pages)
                super().showPage()
            super().save()

        def draw_footer(self, page_count):
            self.saveState()
            self.setFont("Helvetica", 9)
            self.setFillColor(colors.HexColor('#6B7280'))
            self.setStrokeColor(colors.HexColor('#E5E7EB'))
            self.line(54, 45, 612 - 54, 45)
            self.drawString(54, 30, "National Apex University Regulations — Confidential & Official")
            page_text = f"Page {self._pageNumber} of {page_count}"
            self.drawRightString(612 - 54, 30, page_text)
            self.restoreState()

    # 1. Academic_Regulations_2026.pdf
    doc1_path = os.path.join(output_dir, "Academic_Regulations_2026.pdf")
    doc1 = SimpleDocTemplate(doc1_path, pagesize=letter, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    story1 = []

    # Page 1
    story1.append(Paragraph("NATIONAL APEX UNIVERSITY", title_style))
    story1.append(Paragraph("ACADEMIC REGULATIONS & DEGREE REQUIREMENTS (2026)", subtitle_style))
    story1.append(Paragraph("Section 1: General Degree Structure & Credit Framework", h1_style))
    story1.append(Paragraph(
        "1.1. Minimum Credit Requirement: To qualify for the award of a Bachelor of Technology (B.Tech) degree, "
        "a regular candidate must successfully complete a minimum of 160 academic credits distributed over 8 semesters. "
        "Lateral entry students must earn at least 120 credits across 6 semesters.",
        body_style
    ))
    story1.append(Paragraph(
        "1.2. Maximum Duration: The normal curriculum duration is 4 academic years (8 semesters). However, a student "
        "is permitted a maximum extension period of up to 6 academic years (12 semesters) to clear all backlogs and "
        "satisfy degree requirements. Failure to complete within 6 years results in forfeiture of admission.",
        body_style
    ))
    story1.append(Paragraph(
        "1.3. Credit Caps per Semester: In any regular semester, a student can register for a minimum of 16 credits "
        "and a maximum of 26 credits, unless special permission is granted by the Dean of Academic Affairs.",
        body_style
    ))
    story1.append(PageBreak())

    # Page 2
    story1.append(Paragraph("Section 2: Course Registration & Add/Drop Policies", h1_style))
    story1.append(Paragraph(
        "2.1. Mandatory Registration: Every student must formally register for courses prior to the commencement of each semester. "
        "Late course registration is allowed up to 7 calendar days after classes begin with a late fee of $50.",
        body_style
    ))
    story1.append(Paragraph(
        "2.2. Course Add/Drop Period: Students may add or drop elective courses within the first 10 working days of the semester. "
        "Dropped courses within this window will not appear on the official grade card.",
        body_style
    ))
    story1.append(Paragraph(
        "2.3. Course Withdrawal: A student may withdraw from a registered course up to the end of Week 8 with the approval of "
        "the Faculty Advisor. Withdrawn courses will be annotated with a 'W' grade on the transcript and will not impact CGPA.",
        body_style
    ))
    story1.append(PageBreak())

    # Page 3
    story1.append(Paragraph("Section 3: Minimum CGPA & Academic Detention", h1_style))
    story1.append(Paragraph(
        "3.1. Minimum CGPA for Progression: A student must maintain a Cumulative Grade Point Average (CGPA) of at least 5.00 "
        "out of 10.00 at the end of every academic year to progress to the subsequent year.",
        body_style
    ))
    story1.append(Paragraph(
        "3.2. Year-Back / Academic Detention: A candidate who fails to earn at least 50% of the total registered credits "
        "or whose CGPA drops below 4.50 at the end of the second year shall be placed on Academic Detention (Year-Back) "
        "and must repeat the deficient year without registering for advanced courses.",
        body_style
    ))
    story1.append(Paragraph(
        "3.3. Academic Probation: Students with CGPA between 4.50 and 4.99 are placed on Academic Probation for one semester. "
        "They are restricted to registering for a maximum of 18 credits during the probation period.",
        body_style
    ))
    doc1.build(story1, canvasmaker=NumberedCanvas)

    # 2. Attendance_Policy.pdf
    doc2_path = os.path.join(output_dir, "Attendance_Policy.pdf")
    doc2 = SimpleDocTemplate(doc2_path, pagesize=letter, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    story2 = []

    # Page 1
    story2.append(Paragraph("NATIONAL APEX UNIVERSITY", title_style))
    story2.append(Paragraph("STUDENT ATTENDANCE POLICY & LEAVE REGULATIONS", subtitle_style))
    story2.append(Paragraph("Section 1: Mandatory Attendance Thresholds", h1_style))
    story2.append(Paragraph(
        "1.1. Minimum Requirement: Every enrolled student must maintain a minimum attendance of 75% in aggregate across all lectures, "
        "tutorials, practicals, and seminars in each registered course to be eligible to appear for the End-Semester Examination.",
        body_style
    ))
    story2.append(Paragraph(
        "1.2. Continuous Monitoring: Faculty instructors update biometric and LMS attendance logs weekly. A warning email "
        "is dispatched automatically to the student and their registered parent when attendance drops below 80%.",
        body_style
    ))
    story2.append(PageBreak())

    # Page 2
    story2.append(Paragraph("Section 2: Condonation of Attendance Shortage", h1_style))
    story2.append(Paragraph(
        "2.1. Medical Condonation Range: The Academic Council empowers the Vice-Chancellor to grant condonation of attendance shortage "
        "for students having attendance between 65% and 74%, strictly on genuine medical grounds (such as hospitalization or contagious illness).",
        body_style
    ))
    story2.append(Paragraph(
        "2.2. Submission Protocol: Application for medical condonation along with a verified medical certificate from a Registered Medical "
        "Practitioner and hospital discharge summary must be submitted to the Head of Department (HOD) within 3 working days of returning to campus.",
        body_style
    ))
    story2.append(Paragraph(
        "2.3. Condonation Fee: A prescribed condonation processing fee of $40 per course must be paid via the student ERP portal "
        "upon approval of the application.",
        body_style
    ))
    story2.append(Paragraph(
        "2.4. Absolute Shortage: Any student having aggregate attendance strictly below 65% is categorically NOT eligible for condonation "
        "under any circumstances, medical or otherwise.",
        body_style
    ))
    story2.append(PageBreak())

    # Page 3
    story2.append(Paragraph("Section 3: On-Duty (OD) Leaves & Detention Consequences", h1_style))
    story2.append(Paragraph(
        "3.1. Official Duty (OD) Leave: Students representing the University in approved inter-collegiate sports tournaments, cultural festivals, "
        "NSS/NCC camps, or recognized international hackathons are entitled to On-Duty leave up to a maximum of 10% of total instructional hours. "
        "Prior written approval from the Dean of Student Welfare is mandatory.",
        body_style
    ))
    story2.append(Paragraph(
        "3.2. Attendance Detention: A student who fails to satisfy the 75% attendance rule (or 65% with approved condonation) will be awarded "
        "an 'SA' (Shortage of Attendance) grade. Such students are debarred from the End-Semester Examination for that course and must reregister "
        "for the course during the summer term or whenever offered next.",
        body_style
    ))
    doc2.build(story2, canvasmaker=NumberedCanvas)

    # 3. Examination_Guidelines.pdf
    doc3_path = os.path.join(output_dir, "Examination_Guidelines.pdf")
    doc3 = SimpleDocTemplate(doc3_path, pagesize=letter, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    story3 = []

    # Page 1
    story3.append(Paragraph("NATIONAL APEX UNIVERSITY", title_style))
    story3.append(Paragraph("EXAMINATION GUIDELINES & EVALUATION REGULATIONS", subtitle_style))
    story3.append(Paragraph("Section 1: Hall Ticket & Examination Admission", h1_style))
    story3.append(Paragraph(
        "1.1. Hall Ticket Requirement: No candidate will be admitted into the examination hall without a valid University Hall Ticket "
        "and physical University Identity Card. Hall tickets are issued online 5 days before exams provided no fee dues or attendance detentions exist.",
        body_style
    ))
    story3.append(Paragraph(
        "1.2. Reporting Time: Candidates must occupy their designated seats at least 15 minutes before the exam commences. "
        "No student is permitted to enter the hall after 30 minutes from commencement, nor leave before 60 minutes have elapsed.",
        body_style
    ))
    story3.append(PageBreak())

    # Page 2
    story3.append(Paragraph("Section 2: 10-Point Absolute Grading System", h1_style))
    story3.append(Paragraph(
        "2.1. Letter Grades and Grade Points: Student performance is assessed on a 10-point scale:",
        body_style
    ))
    story3.append(Paragraph("• Grade 'O' (Outstanding): 90% to 100% — 10 Grade Points", bullet_style))
    story3.append(Paragraph("• Grade 'A+' (Excellent): 80% to 89% — 9 Grade Points", bullet_style))
    story3.append(Paragraph("• Grade 'A' (Very Good): 70% to 79% — 8 Grade Points", bullet_style))
    story3.append(Paragraph("• Grade 'B+' (Good): 60% to 69% — 7 Grade Points", bullet_style))
    story3.append(Paragraph("• Grade 'B' (Above Average): 55% to 59% — 6 Grade Points", bullet_style))
    story3.append(Paragraph("• Grade 'C' (Average): 50% to 54% — 5 Grade Points", bullet_style))
    story3.append(Paragraph("• Grade 'P' (Pass): 40% to 49% — 4 Grade Points (Minimum pass threshold)", bullet_style))
    story3.append(Paragraph("• Grade 'F' (Fail): Below 40% — 0 Grade Points", bullet_style))
    story3.append(Paragraph("• Grade 'Ab' (Absent): Did not appear — 0 Grade Points", bullet_style))
    story3.append(Paragraph(
        "2.2. Minimum Passing Score: A candidate must score at least 40% in the End-Semester Examination and an aggregate of 40% "
        "(Internal Assessments + End-Semester) to clear any course.",
        body_style
    ))
    story3.append(PageBreak())

    # Page 3
    story3.append(Paragraph("Section 3: Re-evaluation & Answer Script Verification", h1_style))
    story3.append(Paragraph(
        "3.1. Right to Review: A student dissatisfied with their evaluated theory course grade may apply for Answer Script Photocopy "
        "or Re-evaluation within 15 calendar days from the date of online result publication.",
        body_style
    ))
    story3.append(Paragraph(
        "3.2. Fee Schedule: The fee for obtaining an answer script photocopy is $20 per course. The fee for formal re-evaluation "
        "is $60 per course. If re-evaluation results in a grade increase of two or more grades, 50% of the re-evaluation fee will be refunded.",
        body_style
    ))
    story3.append(Paragraph(
        "3.3. Supplementary Examinations: Supplementary exams are conducted once each year during the winter vacation (December) "
        "and summer vacation (July). A student may appear for a maximum of 4 backlogs in one supplementary session.",
        body_style
    ))
    doc3.build(story3, canvasmaker=NumberedCanvas)

    # 4. Student_Code_of_Conduct.pdf
    doc4_path = os.path.join(output_dir, "Student_Code_of_Conduct.pdf")
    doc4 = SimpleDocTemplate(doc4_path, pagesize=letter, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    story4 = []

    # Page 1
    story4.append(Paragraph("NATIONAL APEX UNIVERSITY", title_style))
    story4.append(Paragraph("STUDENT CODE OF CONDUCT & DISCIPLINARY MANUAL", subtitle_style))
    story4.append(Paragraph("Section 1: Examination Malpractice Categories & Penalties", h1_style))
    story4.append(Paragraph(
        "1.1. Category 1 (Minor Infraction): Possession of unauthorized paper slips, unauthorized writing on hands/rulers, "
        "or talking in the examination hall without evidence of copying. Penalty: Cancellation of the examination for that specific course.",
        body_style
    ))
    story4.append(Paragraph(
        "1.2. Category 2 (Major Infraction): Possession or usage of mobile phones, smart watches, Bluetooth earbuds, copying from smuggled material, "
        "or exchanging answer booklets. Penalty: Cancellation of all examinations registered in that semester, and debarment from the next regular semester.",
        body_style
    ))
    story4.append(Paragraph(
        "1.3. Category 3 (Severe Impersonation / Fraud): Impersonating another candidate, hiring an impersonator, or assaulting an invigilator. "
        "Penalty: Immediate expulsion from the University and filing of a formal First Information Report (FIR) with law enforcement.",
        body_style
    ))
    story4.append(PageBreak())

    # Page 2
    story4.append(Paragraph("Section 2: Anti-Ragging & Campus Safety", h1_style))
    story4.append(Paragraph(
        "2.1. Zero Tolerance Policy: Ragging in any form—physical assault, verbal abuse, psychological intimidation, forced servitude, "
        "or harassment inside or outside campus hostels—is strictly forbidden under Supreme Court guidelines and University Statutes.",
        body_style
    ))
    story4.append(Paragraph(
        "2.2. Penalties for Ragging: Any student found guilty of ragging by the Anti-Ragging Committee will face immediate suspension, "
        "cancellation of hostel accommodation, debarment from campus placement, and rustication for a period of up to 2 academic years.",
        body_style
    ))
    story4.append(Paragraph(
        "2.3. Grievance Redressal: Complaints may be lodged directly to the Proctorial Board or submitted confidentially via the online "
        "Anti-Ragging Portal. The committee must conclude proceedings and issue findings within 7 working days.",
        body_style
    ))
    doc4.build(story4, canvasmaker=NumberedCanvas)

    print(f"[SUCCESS] All 4 sample regulation PDFs successfully generated in: {output_dir}")

if __name__ == "__main__":
    out_dir = sys.argv[1] if len(sys.argv) > 1 else "data/samples"
    create_sample_pdfs(out_dir)
