"""
Retriever Module for University Regulation RAG.

Coordinates query embedding, metadata pre-filtering, similarity ranking,
and confidence thresholding to prevent hallucination of out-of-domain answers.
"""

from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np

from rag.chunker import DocumentChunk
from rag.embeddings import BaseEmbeddingEngine
from rag.vector_store import UniversityVectorStore


@dataclass
class RetrievalResult:
    """Encapsulates retrieval outputs and confidence diagnostics."""
    query: str
    chunks: List[Tuple[DocumentChunk, float]]
    top_score: float
    has_grounded_context: bool
    filtered_by: Optional[Dict[str, Any]] = None

    @property
    def sources_cited(self) -> List[Dict[str, Any]]:
        """Returns structured citations: document name, page number, score, chunk preview."""
        citations = []
        seen = set()
        for chunk, score in self.chunks:
            key = (chunk.source, chunk.page)
            if key not in seen:
                seen.add(key)
                citations.append({
                    "source": chunk.source,
                    "page": chunk.page,
                    "category": chunk.category,
                    "score": round(score * 100, 1),
                    "chunk_id": chunk.chunk_id,
                    "excerpt": chunk.content[:180] + ("..." if len(chunk.content) > 180 else "")
                })
        return citations


class UniversityRetriever:
    """
    High-level retriever connecting embedding models and vector index.
    Includes hallucination reduction safeguards:
    - If the top similarity score is below `min_similarity_threshold`,
      it marks `has_grounded_context = False`.
    """

    def __init__(
        self,
        vector_store: UniversityVectorStore,
        embedding_engine: BaseEmbeddingEngine,
        default_top_k: int = 4,
        min_similarity_threshold: float = 0.35,
    ):
        self.vector_store = vector_store
        self.embedding_engine = embedding_engine
        self.default_top_k = default_top_k
        self.min_similarity_threshold = min_similarity_threshold

    def retrieve(
        self,
        query: str,
        top_k: Optional[int] = None,
        metadata_filter: Optional[Dict[str, Any]] = None,
        custom_threshold: Optional[float] = None,
    ) -> RetrievalResult:
        """
        Retrieves relevant chunks for a user question.

        Steps:
        1. Embed the query string into normalized vector space.
        2. Execute similarity search in vector store (with metadata pre-filter).
        3. Evaluate confidence against similarity threshold.
        """
        k = top_k or self.default_top_k
        threshold = custom_threshold if custom_threshold is not None else self.min_similarity_threshold

        query_vec = self.embedding_engine.embed_query(query)
        scored_chunks = self.vector_store.similarity_search(
            query_vector=query_vec,
            top_k=k,
            where=metadata_filter,
            min_score=0.0  # Retrieve all to inspect top score
        )

        top_score = scored_chunks[0][1] if scored_chunks else 0.0

        # Hallucination check: must exceed threshold to be considered grounded
        has_grounded_context = (top_score >= threshold) and (len(scored_chunks) > 0)

        # Filter out chunks that do not meet the threshold
        valid_chunks = [
            (chunk, score) for chunk, score in scored_chunks
            if score >= threshold
        ]

        return RetrievalResult(
            query=query,
            chunks=valid_chunks if has_grounded_context else [],
            top_score=top_score,
            has_grounded_context=has_grounded_context,
            filtered_by=metadata_filter
        )
