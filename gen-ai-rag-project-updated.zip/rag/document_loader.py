"""
Document Loading and Preprocessing Module for University Regulation RAG.

Handles page-by-page extraction from PDF files, text cleaning, normalization,
and metadata enrichment (source, page number, regulation category, timestamp).
"""

import os
import re
import io
from typing import List, Dict, Any, Union, BinaryIO
from dataclasses import dataclass, field
import pypdf


@dataclass
class DocumentPage:
    """Represents a single preprocessed page extracted from a university document."""
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def source(self) -> str:
        return self.metadata.get("source", "Unknown Document")

    @property
    def page_number(self) -> int:
        return self.metadata.get("page", 1)

    @property
    def category(self) -> str:
        return self.metadata.get("category", "General Regulation")


def infer_regulation_category(filename: str, sample_text: str = "") -> str:
    """
    Infers the regulation domain from document filename and content.
    Used for Viva Focus: Metadata Filtering.
    """
    fn = filename.lower()
    if any(k in fn for k in ["attend", "leave", "condonation", "shortage"]):
        return "Attendance Policy"
    if any(k in fn for k in ["conduct", "discipline", "ragging", "handbook", "grievance", "code"]):
        return "Student Conduct & Handbook"
    if any(k in fn for k in ["exam", "grade", "grading", "evaluat", "revaluation"]):
        return "Examination & Grading"
    if any(k in fn for k in ["academic", "curriculum", "credit", "degree", "detention", "registration"]):
        return "Academic Regulations"

    # Fallback to sample text if filename is ambiguous
    text_lower = sample_text[:1000].lower()
    if any(k in text_lower for k in ["conduct", "discipline", "ragging", "handbook", "grievance", "malpractice"]):
        return "Student Conduct & Handbook"
    if any(k in text_lower for k in ["attendance", "leave", "condonation", "shortage"]):
        return "Attendance Policy"
    if any(k in text_lower for k in ["exam", "evaluation", "grading", "revaluation", "cgpa"]):
        return "Examination & Grading"
    if any(k in text_lower for k in ["academic", "curriculum", "credit", "degree"]):
        return "Academic Regulations"
    return "General Regulation"


def preprocess_text(text: str) -> str:
    """
    Cleans raw extracted PDF text:
    - Normalizes Unicode spaces and non-breaking characters
    - Fixes hyphenated line breaks (e.g. 'regu-\nlation' -> 'regulation')
    - Standardizes paragraph breaks while removing excessive blank lines
    - Removes unprintable control characters while preserving formatting
    """
    if not text:
        return ""

    # Normalize space characters
    text = text.replace("\xa0", " ").replace("\r\n", "\n").replace("\r", "\n")

    # Rejoin words broken across line breaks with a hyphen
    text = re.sub(r'(\w+)-\n(\w+)', r'\1\2', text)

    # Clean non-printable control characters except standard whitespace
    text = "".join(ch for ch in text if ch.isprintable() or ch in ["\n", "\t"])

    # Collapse multiple inline spaces/tabs into a single space
    lines = []
    for line in text.split("\n"):
        cleaned_line = re.sub(r'[ \t]+', ' ', line).strip()
        lines.append(cleaned_line)

    cleaned_text = "\n".join(lines)

    # Collapse more than two consecutive newlines into two
    cleaned_text = re.sub(r'\n{3,}', '\n\n', cleaned_text).strip()

    return cleaned_text


def load_pdf_from_path(file_path: str) -> List[DocumentPage]:
    """Loads and preprocesses all pages from a PDF file path."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"PDF file not found: {file_path}")

    filename = os.path.basename(file_path)
    pages: List[DocumentPage] = []

    with open(file_path, "rb") as f:
        reader = pypdf.PdfReader(f)
        total_pages = len(reader.pages)
        first_page_sample = ""

        if total_pages > 0:
            first_page_sample = reader.pages[0].extract_text() or ""
        category = infer_regulation_category(filename, first_page_sample)

        for page_idx, page in enumerate(reader.pages):
            raw_text = page.extract_text() or ""
            cleaned_text = preprocess_text(raw_text)

            if not cleaned_text:
                continue

            metadata = {
                "source": filename,
                "file_path": file_path,
                "page": page_idx + 1,
                "total_pages": total_pages,
                "category": category,
                "char_count": len(cleaned_text),
            }
            pages.append(DocumentPage(content=cleaned_text, metadata=metadata))

    return pages


def load_pdf_from_stream(file_stream: Union[BinaryIO, bytes, io.BytesIO], filename: str) -> List[DocumentPage]:
    """Loads and preprocesses pages from an in-memory PDF stream (e.g. Streamlit upload)."""
    if isinstance(file_stream, bytes):
        stream = io.BytesIO(file_stream)
    else:
        stream = file_stream

    reader = pypdf.PdfReader(stream)
    total_pages = len(reader.pages)
    pages: List[DocumentPage] = []

    first_page_sample = ""
    if total_pages > 0:
        first_page_sample = reader.pages[0].extract_text() or ""
    category = infer_regulation_category(filename, first_page_sample)

    for page_idx, page in enumerate(reader.pages):
        raw_text = page.extract_text() or ""
        cleaned_text = preprocess_text(raw_text)

        if not cleaned_text:
            continue

        metadata = {
            "source": filename,
            "page": page_idx + 1,
            "total_pages": total_pages,
            "category": category,
            "char_count": len(cleaned_text),
        }
        pages.append(DocumentPage(content=cleaned_text, metadata=metadata))

    return pages


def load_multiple_pdfs(files: List[Union[str, tuple]]) -> List[DocumentPage]:
    """
    Ingests a list of files or file paths.
    Tuple format: (file_stream_or_bytes, filename)
    """
    all_pages: List[DocumentPage] = []
    for item in files:
        if isinstance(item, str):
            all_pages.extend(load_pdf_from_path(item))
        elif isinstance(item, tuple) and len(item) == 2:
            stream_or_bytes, name = item
            all_pages.extend(load_pdf_from_stream(stream_or_bytes, name))
    return all_pages
