"""
Chunking Module for University Regulation RAG.

Implements Recursive Character Text Splitting with configurable chunk size and overlap,
preserving page-level metadata and tracking chunk boundaries for explainable retrieval.
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from rag.document_loader import DocumentPage


@dataclass
class DocumentChunk:
    """A single semantic chunk with source metadata, ready for embedding and retrieval."""
    chunk_id: str
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def source(self) -> str:
        return self.metadata.get("source", "Unknown Document")

    @property
    def page(self) -> int:
        return self.metadata.get("page", 1)

    @property
    def category(self) -> str:
        return self.metadata.get("category", "General")

    @property
    def char_count(self) -> int:
        return len(self.content)


class RecursiveCharacterChunker:
    """
    Splits document text into semantic chunks hierarchically.
    Hierarchy:
    1. Paragraph breaks ('\\n\\n')
    2. Line breaks ('\\n')
    3. Sentence terminators ('. ', '! ', '? ')
    4. Semicolon/clause breaks ('; ')
    5. Word breaks (' ')
    6. Character boundaries ('')

    Viva Focus:
    - Chunk Size: Controls granularity vs context. Small chunks (e.g. 200 chars) miss overarching rules;
      large chunks (e.g. 2000 chars) dilute specific facts like percentages or fees.
    - Chunk Overlap: Guarantees that clauses spanning boundary splits retain complete context.
    """

    def __init__(
        self,
        chunk_size: int = 600,
        chunk_overlap: int = 100,
        separators: Optional[List[str]] = None,
    ):
        if chunk_overlap >= chunk_size:
            raise ValueError(f"chunk_overlap ({chunk_overlap}) must be strictly smaller than chunk_size ({chunk_size})")

        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or ["\n\n", "\n", ". ", "; ", " ", ""]

    def _split_text(self, text: str, separators: List[str]) -> List[str]:
        """Recursively splits text using the highest-priority separator that fits."""
        final_chunks: List[str] = []

        # Find the first separator present in text
        separator = ""
        new_separators = []
        for i, sep in enumerate(separators):
            if sep == "":
                separator = ""
                break
            if sep in text:
                separator = sep
                new_separators = separators[i + 1:]
                break

        splits = text.split(separator) if separator else list(text)

        good_splits: List[str] = []
        for s in splits:
            if separator and s:
                # Retain the separator at the end of parts if not trailing
                piece = s if s.endswith(separator) else s + separator
            else:
                piece = s

            if len(piece) <= self.chunk_size:
                good_splits.append(piece)
            else:
                if new_separators:
                    sub_splits = self._split_text(piece, new_separators)
                    good_splits.extend(sub_splits)
                else:
                    # Hard split by character count if no separators left
                    for k in range(0, len(piece), self.chunk_size - self.chunk_overlap):
                        good_splits.append(piece[k:k + self.chunk_size])

        # Merge pieces up to chunk_size with chunk_overlap
        current_chunk = ""
        for piece in good_splits:
            if not piece.strip():
                continue

            if not current_chunk:
                current_chunk = piece
            elif len(current_chunk) + len(piece) <= self.chunk_size:
                current_chunk += piece
            else:
                final_chunks.append(current_chunk.strip())
                # Create overlap buffer from end of current_chunk
                overlap_text = current_chunk[-self.chunk_overlap:] if self.chunk_overlap > 0 else ""
                current_chunk = overlap_text + piece

        if current_chunk.strip():
            final_chunks.append(current_chunk.strip())

        return final_chunks

    def chunk_document_page(self, page: DocumentPage, start_idx: int = 0) -> List[DocumentChunk]:
        """Splits a single document page into chunks, tagging page metadata."""
        raw_chunks = self._split_text(page.content, self.separators)
        chunks: List[DocumentChunk] = []

        for idx, text in enumerate(raw_chunks):
            chunk_num = start_idx + idx
            chunk_id = f"{page.source}_p{page.page_number}_c{chunk_num}"

            metadata = dict(page.metadata)
            metadata.update({
                "chunk_id": chunk_id,
                "chunk_index": chunk_num,
                "chunk_char_count": len(text),
                "source": page.source,
                "page": page.page_number,
                "category": page.category,
            })

            chunks.append(DocumentChunk(
                chunk_id=chunk_id,
                content=text,
                metadata=metadata
            ))

        return chunks

    def chunk_pages(self, pages: List[DocumentPage]) -> List[DocumentChunk]:
        """Chunks a collection of document pages while maintaining consistent IDs."""
        all_chunks: List[DocumentChunk] = []
        counter = 0
        for page in pages:
            page_chunks = self.chunk_document_page(page, start_idx=counter)
            all_chunks.extend(page_chunks)
            counter += len(page_chunks)
        return all_chunks
