"""
Generator Module for University Regulation RAG.

Synthesizes grounded answers strictly conditioned on retrieved context chunks.
Implements multi-layer hallucination reduction:
1. Retrieval Confidence Gate: Short-circuits generation if top similarity < threshold.
2. Grounded System Prompt: Enforces strict adherence to context and mandates [Doc, Page] citations.
3. Fallback Response: Returns standard refusal when facts are absent.
4. Dual Generator Engines: Google Gemini (Cloud LLM) and Local Grounded Extractor (Offline).
"""

import re
from typing import Dict, Any, Optional
from rag.retriever import RetrievalResult

REFUSAL_MESSAGE = "I cannot find the answer to this question in the provided university regulations and documents."

GROUNDED_SYSTEM_PROMPT = """You are the official University Academic Regulations & Compliance AI Assistant.
Your mission is to provide accurate, factual, and strictly grounded answers based ONLY on the provided context excerpts from university documents.

CRITICAL COMPLIANCE RULES:
1. Grounding: Answer ONLY using the facts explicitly stated in the context excerpts below. Do NOT use outside knowledge, assumptions, or rules from other universities.
2. Citation: For EVERY policy, number, percentage, deadline, or requirement you state, cite the exact source document and page number in brackets, for example: [Attendance_Policy.pdf, Page 2].
3. Negative Constraint / No Hallucination: If the provided excerpts do not contain enough information to completely and accurately answer the question, state EXACTLY:
"{refusal_message}"
Do not attempt to guess or give partial speculative advice if the rule is not in the text.
4. Tone: Clear, formal, authoritative, and helpful to university students and faculty.
""".format(refusal_message=REFUSAL_MESSAGE)


class BaseGenerator:
    """Abstract interface for answer generation."""
    def generate(self, result: RetrievalResult) -> Dict[str, Any]:
        raise NotImplementedError


class GeminiGenerator(BaseGenerator):
    """
    Google Gemini 2.5 Flash grounded generator.
    """

    def __init__(self, api_key: str, model_name: str = "gemini-2.5-flash"):
        self.api_key = api_key
        self.model_name = model_name
        self.fallback = LocalGroundedGenerator()

        try:
            from google import genai
            self.client = genai.Client(api_key=api_key)
        except Exception:
            self.client = None

    def generate(self, result: RetrievalResult) -> Dict[str, Any]:
        # Layer 1 Hallucination Guard: Reject if no chunks passed relevance threshold
        if not result.has_grounded_context or not result.chunks:
            return {
                "answer": REFUSAL_MESSAGE,
                "is_grounded": False,
                "citations": [],
                "reason": "Top retrieval score was below confidence threshold (out-of-domain query)."
            }

        # Build context block
        context_parts = []
        for chunk, score in result.chunks:
            context_parts.append(
                f"--- EXCERPT FROM [{chunk.source}, Page {chunk.page}] (Category: {chunk.category}) ---\n"
                f"{chunk.content}\n"
            )
        context_str = "\n".join(context_parts)

        user_prompt = (
            f"CONTEXT FROM UNIVERSITY REGULATIONS:\n"
            f"{context_str}\n\n"
            f"STUDENT QUERY: {result.query}\n\n"
            f"Please answer the student query following all compliance and citation rules."
        )

        if not self.client:
            return self.fallback.generate(result)

        try:
            from google.genai import types
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=user_prompt,
                config=types.GenerateContentConfig(
                    system_instruction=GROUNDED_SYSTEM_PROMPT,
                    temperature=0.1,  # Low temperature to suppress creative hallucination
                )
            )

            answer_text = response.text.strip()
            is_refusal = REFUSAL_MESSAGE.lower() in answer_text.lower()

            return {
                "answer": answer_text,
                "is_grounded": not is_refusal,
                "citations": [] if is_refusal else result.sources_cited,
                "reason": "Grounded via Gemini 2.5 Flash" if not is_refusal else "Refused: Not found in text"
            }

        except Exception as e:
            print(f"[GeminiGenerator] API call failed ({e}), using Local Grounded Extractor.")
            return self.fallback.generate(result)


class LocalGroundedGenerator(BaseGenerator):
    """
    Deterministic grounded extractive generator for 100% offline viva testing.
    Extracts key regulatory sentences, calculates query term overlap, formats citations,
    and strictly respects the refusal constraint.
    """

    def generate(self, result: RetrievalResult) -> Dict[str, Any]:
        # Layer 1 Hallucination Guard
        if not result.has_grounded_context or not result.chunks:
            return {
                "answer": REFUSAL_MESSAGE,
                "is_grounded": False,
                "citations": [],
                "reason": "Top retrieval score was below confidence threshold (out-of-domain query)."
            }

        query_words = set(re.findall(r'\b[a-zA-Z0-9]{3,}\b', result.query.lower()))
        # Remove common query stop words
        query_words -= {"what", "when", "where", "which", "who", "whom", "this", "that", "these", "those",
                        "have", "with", "from", "your", "does", "rule", "policy", "regulation", "guideline"}

        grounded_paragraphs = []
        citations_used = []

        for chunk, score in result.chunks:
            sentences = re.split(r'(?<=[.!?])\s+', chunk.content)
            matching_sentences = []

            for s in sentences:
                s_words = set(re.findall(r'\b[a-zA-Z0-9]{3,}\b', s.lower()))
                overlap = query_words.intersection(s_words)
                if len(overlap) >= 1:
                    matching_sentences.append(s.strip())

            if matching_sentences:
                passage = " ".join(matching_sentences[:3])
                citation_tag = f"**[{chunk.source}, Page {chunk.page}]**"
                grounded_paragraphs.append(f"{citation_tag}\n> \"{passage}\"")
                citations_used.append({
                    "source": chunk.source,
                    "page": chunk.page,
                    "category": chunk.category,
                    "score": round(score * 100, 1),
                    "chunk_id": chunk.chunk_id,
                    "excerpt": passage
                })

        if not grounded_paragraphs:
            return {
                "answer": REFUSAL_MESSAGE,
                "is_grounded": False,
                "citations": [],
                "reason": "No relevant regulatory clauses matched the specific query intent."
            }

        answer_text = (
            f"Based on the official university documents, here are the applicable regulations:\n\n"
            + "\n\n".join(grounded_paragraphs)
        )

        return {
            "answer": answer_text,
            "is_grounded": True,
            "citations": result.sources_cited,
            "reason": "Synthesized via Local Grounded Extractor"
        }


def get_generator(provider: str = "local", api_key: Optional[str] = None) -> BaseGenerator:
    """Factory helper to obtain the appropriate generator."""
    if provider.lower() == "gemini" and api_key:
        return GeminiGenerator(api_key=api_key)
    return LocalGroundedGenerator()
