"""
Vector Store Module for University Regulation RAG.

Supports both FAISS and ChromaDB paradigms with:
- Dense vector similarity indexing (Inner Product / Cosine Similarity)
- Metadata indexing & Pre-filtering (filter by document, regulation category, page)
- Local persistence to disk
- Seamless FAISS/ChromaDB switching for Viva comparison

Viva Focus:
- Exact Search (IndexFlatIP/IndexFlatL2) vs Approximate Nearest Neighbor (ANN - IVF/HNSW).
- Metadata Filtering: How pre-filtering restricts vector distance computation to a filtered subset of documents.
- Cosine Similarity: Range [-1, 1], normalized to [0, 1] confidence percentage.
"""

import os
import json
import pickle
from typing import List, Dict, Any, Optional, Tuple
import numpy as np

from rag.chunker import DocumentChunk

# Try importing native FAISS if installed
try:
    import faiss
    HAS_FAISS = True
except ImportError:
    HAS_FAISS = False


class VectorIndexBase:
    """Interface for low-level vector indexing."""
    def add(self, vectors: np.ndarray):
        raise NotImplementedError
    def search(self, query_vector: np.ndarray, top_k: int) -> Tuple[np.ndarray, np.ndarray]:
        raise NotImplementedError


class NativeFAISSIndex(VectorIndexBase):
    """Wraps native faiss.IndexFlatIP for exact cosine similarity search."""
    def __init__(self, dimension: int):
        self.dimension = dimension
        self.index = faiss.IndexFlatIP(dimension)

    def add(self, vectors: np.ndarray):
        vectors = np.ascontiguousarray(vectors, dtype=np.float32)
        self.index.add(vectors)

    def search(self, query_vector: np.ndarray, top_k: int) -> Tuple[np.ndarray, np.ndarray]:
        q = np.ascontiguousarray(query_vector.reshape(1, -1), dtype=np.float32)
        distances, indices = self.index.search(q, top_k)
        return distances[0], indices[0]


class PureNumpyFAISSIndex(VectorIndexBase):
    """
    High-performance pure-NumPy exact vector index implementing IndexFlatIP.
    Guarantees 100% platform portability and identical math to FAISS.
    """
    def __init__(self, dimension: int):
        self.dimension = dimension
        self.vectors: Optional[np.ndarray] = None

    def add(self, vectors: np.ndarray):
        vectors = np.ascontiguousarray(vectors, dtype=np.float32)
        if self.vectors is None:
            self.vectors = vectors
        else:
            self.vectors = np.vstack([self.vectors, vectors])

    def search(self, query_vector: np.ndarray, top_k: int) -> Tuple[np.ndarray, np.ndarray]:
        if self.vectors is None or len(self.vectors) == 0:
            return np.array([]), np.array([], dtype=int)

        # Dot product with all normalized vectors gives exact cosine similarity
        q = query_vector.reshape(-1)
        sims = np.dot(self.vectors, q)

        # Retrieve top_k indices sorted descending
        k = min(top_k, len(sims))
        top_indices = np.argsort(sims)[::-1][:k]
        top_scores = sims[top_indices]

        return top_scores, top_indices


class UniversityVectorStore:
    """
    Unified Vector Store managing chunks, metadata, and embeddings.
    Supports:
    - Mode 'FAISS': Uses FAISS-style dense vector similarity indexing.
    - Mode 'ChromaDB': Emulates ChromaDB's document collection structure with rich metadata where-clauses.
    """

    def __init__(self, store_type: str = "FAISS"):
        self.store_type = store_type.upper()
        self.chunks: List[DocumentChunk] = []
        self.vectors: Optional[np.ndarray] = None
        self.index: Optional[VectorIndexBase] = None
        self.dimension: int = 0

    def clear(self):
        """Resets the vector store."""
        self.chunks = []
        self.vectors = None
        self.index = None
        self.dimension = 0

    def add_chunks(self, chunks: List[DocumentChunk], embeddings: np.ndarray):
        """Indexes document chunks along with their precomputed embeddings."""
        if len(chunks) == 0:
            return

        if len(chunks) != len(embeddings):
            raise ValueError(f"Chunks count ({len(chunks)}) != embeddings count ({len(embeddings)})")

        self.dimension = embeddings.shape[1]
        self.chunks.extend(chunks)

        if self.vectors is None:
            self.vectors = embeddings.astype(np.float32)
        else:
            self.vectors = np.vstack([self.vectors, embeddings.astype(np.float32)])

        # Initialize index
        if self.store_type == "FAISS" and HAS_FAISS:
            self.index = NativeFAISSIndex(self.dimension)
            self.index.add(self.vectors)
        else:
            self.index = PureNumpyFAISSIndex(self.dimension)
            self.index.add(self.vectors)

    def similarity_search(
        self,
        query_vector: np.ndarray,
        top_k: int = 4,
        where: Optional[Dict[str, Any]] = None,
        min_score: float = 0.0,
    ) -> List[Tuple[DocumentChunk, float]]:
        """
        Performs vector similarity search with optional metadata pre-filtering.

        Viva Focus - Metadata Filtering:
        Pre-filtering eliminates chunks that do not match metadata constraints (e.g. document name or category)
        before ranking, saving computation and eliminating cross-document confusion.
        """
        if self.vectors is None or len(self.chunks) == 0:
            return []

        q = query_vector.reshape(-1)

        # 1. Apply metadata filtering if specified
        valid_indices = []
        for i, chunk in enumerate(self.chunks):
            if where:
                match = True
                for key, expected_val in where.items():
                    if not expected_val:
                        continue
                    chunk_val = chunk.metadata.get(key)
                    if isinstance(expected_val, list):
                        if chunk_val not in expected_val:
                            match = False
                            break
                    elif chunk_val != expected_val:
                        match = False
                        break
                if not match:
                    continue
            valid_indices.append(i)

        if not valid_indices:
            return []

        # 2. Compute similarity for candidate subset
        candidate_vectors = self.vectors[valid_indices]
        sims = np.dot(candidate_vectors, q)

        # Clamp cosine similarity to [0.0, 1.0] for clean confidence interpretation
        sims = np.clip(sims, 0.0, 1.0)

        # 3. Sort descending and filter by min_score
        sorted_order = np.argsort(sims)[::-1]

        results: List[Tuple[DocumentChunk, float]] = []
        for rank_idx in sorted_order:
            score = float(sims[rank_idx])
            if score < min_score:
                continue

            orig_idx = valid_indices[rank_idx]
            results.append((self.chunks[orig_idx], score))
            if len(results) >= top_k:
                break

        return results

    def get_all_documents(self) -> List[str]:
        """Returns unique document sources in index."""
        return sorted(list({c.source for c in self.chunks}))

    def get_all_categories(self) -> List[str]:
        """Returns unique categories in index."""
        return sorted(list({c.category for c in self.chunks}))

    def save_local(self, save_dir: str):
        """Persists the vector store to disk."""
        os.makedirs(save_dir, exist_ok=True)
        meta_path = os.path.join(save_dir, "metadata.json")
        vec_path = os.path.join(save_dir, "vectors.npy")

        serialized_chunks = [
            {"chunk_id": c.chunk_id, "content": c.content, "metadata": c.metadata}
            for c in self.chunks
        ]

        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump({
                "store_type": self.store_type,
                "dimension": self.dimension,
                "chunks": serialized_chunks
            }, f, indent=2)

        if self.vectors is not None:
            np.save(vec_path, self.vectors)

    def load_local(self, save_dir: str) -> bool:
        """Loads a persisted vector store from disk."""
        meta_path = os.path.join(save_dir, "metadata.json")
        vec_path = os.path.join(save_dir, "vectors.npy")

        if not os.path.exists(meta_path) or not os.path.exists(vec_path):
            return False

        with open(meta_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        self.store_type = data.get("store_type", "FAISS")
        self.dimension = data.get("dimension", 0)
        self.chunks = [
            DocumentChunk(chunk_id=item["chunk_id"], content=item["content"], metadata=item["metadata"])
            for item in data.get("chunks", [])
        ]
        self.vectors = np.load(vec_path).astype(np.float32)

        if self.store_type == "FAISS" and HAS_FAISS:
            self.index = NativeFAISSIndex(self.dimension)
            self.index.add(self.vectors)
        else:
            self.index = PureNumpyFAISSIndex(self.dimension)
            self.index.add(self.vectors)

        return True
