"""
Embeddings Module for University Regulation RAG.

Provides a unified interface for text embeddings:
1. Google Gemini Embeddings ('text-embedding-004', 768-dim) via google-genai or REST API.
2. Local High-Dimensional Dense Embeddings (384-dim, offline, zero-dependency, normalized).

Viva Focus:
- Embeddings project discrete text tokens into a continuous geometric vector space.
- Semantic Proximity: Texts with similar regulatory intent (e.g. "attendance shortage" and "missed classes")
  have small angular distance (high cosine similarity).
- Normalization: Dividing each vector by its Euclidean norm (L2 norm) ensures dot product == cosine similarity.
"""

import math
import hashlib
import re
from typing import List, Optional
import numpy as np


class BaseEmbeddingEngine:
    """Abstract base class for embedding engines."""

    @property
    def dimension(self) -> int:
        raise NotImplementedError

    def embed_documents(self, texts: List[str]) -> np.ndarray:
        raise NotImplementedError

    def embed_query(self, text: str) -> np.ndarray:
        raise NotImplementedError


def _l2_normalize(vectors: np.ndarray) -> np.ndarray:
    """Normalizes vector rows to unit length so dot product == cosine similarity."""
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1e-12
    return vectors / norms


STOP_WORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are",
    "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", "by",
    "can", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from",
    "further", "had", "has", "have", "having", "he", "her", "here", "hers", "him", "his", "how",
    "i", "if", "in", "into", "is", "it", "its", "me", "more", "most", "my", "no", "nor", "not",
    "of", "off", "on", "once", "only", "or", "other", "our", "out", "over", "own", "same", "she",
    "should", "so", "some", "such", "than", "that", "the", "their", "them", "then", "there", "these",
    "they", "this", "those", "through", "to", "too", "under", "until", "up", "very", "was", "we",
    "were", "what", "when", "where", "which", "while", "who", "whom", "why", "with", "would", "you", "your"
}


class LocalDenseEmbeddingEngine(BaseEmbeddingEngine):
    """
    Self-contained, fast, deterministic local dense semantic embedder (384 dimensions).
    Combines subword n-gram hashing with inverse document frequency (IDF) weighting,
    ensuring 100% offline functionality without requiring GPU, PyTorch, or external APIs.
    """

    def __init__(self, dimension: int = 384):
        self._dim = dimension
        self.doc_freq: dict = {}
        self.total_docs: int = 0

    @property
    def dimension(self) -> int:
        return self._dim

    def _tokenize(self, text: str) -> List[str]:
        """Extracts words and alphanumeric tokens."""
        return re.findall(r'\b[a-zA-Z0-9_-]{2,}\b', text.lower())

    def fit(self, texts: List[str]):
        """Fits term statistics over the document corpus for IDF weighting."""
        self.total_docs = max(1, len(texts))
        self.doc_freq.clear()
        for text in texts:
            words = set(self._tokenize(text))
            for w in words:
                if w not in STOP_WORDS:
                    self.doc_freq[w] = self.doc_freq.get(w, 0) + 1

    def _text_to_dense_vector(self, text: str) -> np.ndarray:
        """Converts text into a 384-dimensional dense vector using multi-hash n-grams and IDF."""
        vec = np.zeros(self._dim, dtype=np.float32)
        tokens = self._tokenize(text)

        if not tokens:
            return vec

        # Subword n-grams + word tokens
        features = []
        for t in tokens:
            weight = 0.05 if t in STOP_WORDS else 1.0
            features.append((t, weight))
            if len(t) >= 4 and t not in STOP_WORDS:
                features.append((t[:3], 0.6))
                features.append((t[-3:], 0.6))
                features.append((t[:4], 0.8))

        for feat, w_factor in features:
            # Word salience / IDF
            df = self.doc_freq.get(feat, 1)
            idf = (math.log((self.total_docs + 2.0) / (df + 1.0)) + 1.0) * w_factor

            # Double hashing to distribute energy across dimensions
            h1 = int(hashlib.md5(feat.encode('utf-8')).hexdigest()[:8], 16)
            h2 = int(hashlib.sha256(feat.encode('utf-8')).hexdigest()[:8], 16)

            idx1 = h1 % self._dim
            sign1 = 1.0 if (h1 & 0x100) else -1.0

            idx2 = h2 % self._dim
            sign2 = 1.0 if (h2 & 0x100) else -1.0

            vec[idx1] += sign1 * idf
            vec[idx2] += sign2 * idf * 0.5

        # Normalize to unit sphere
        norm = np.linalg.norm(vec)
        if norm > 1e-12:
            vec /= norm
        return vec

    def embed_documents(self, texts: List[str]) -> np.ndarray:
        if not self.doc_freq:
            self.fit(texts)
        matrix = np.zeros((len(texts), self._dim), dtype=np.float32)
        for i, text in enumerate(texts):
            matrix[i] = self._text_to_dense_vector(text)
        return _l2_normalize(matrix)

    def embed_query(self, text: str) -> np.ndarray:
        vec = self._text_to_dense_vector(text)
        matrix = np.expand_dims(vec, axis=0)
        return _l2_normalize(matrix)[0]


class GeminiEmbeddingEngine(BaseEmbeddingEngine):
    """
    Google Gemini Embeddings using official 'text-embedding-004' (768 dimensions).
    """

    def __init__(self, api_key: str, model_name: str = "text-embedding-004"):
        self.api_key = api_key
        self.model_name = model_name
        self._dim = 768
        self._fallback_local = LocalDenseEmbeddingEngine(dimension=768)

        # Lazy init client
        try:
            from google import genai
            self.client = genai.Client(api_key=api_key)
        except Exception:
            self.client = None

    @property
    def dimension(self) -> int:
        return self._dim

    def embed_documents(self, texts: List[str]) -> np.ndarray:
        if not self.client:
            return self._fallback_local.embed_documents(texts)

        try:
            embeddings = []
            # Batch in groups of 32 to conform with API limits
            batch_size = 32
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                response = self.client.models.embed_content(
                    model=self.model_name,
                    contents=batch,
                )
                for item in response.embeddings:
                    embeddings.append(item.values)

            matrix = np.array(embeddings, dtype=np.float32)
            self._dim = matrix.shape[1]
            return _l2_normalize(matrix)
        except Exception as e:
            # Graceful fallback to local dense if quota exceeded or offline
            print(f"[GeminiEmbeddingEngine] API call failed ({e}), falling back to local dense embeddings.")
            return self._fallback_local.embed_documents(texts)

    def embed_query(self, text: str) -> np.ndarray:
        if not self.client:
            return self._fallback_local.embed_query(text)

        try:
            response = self.client.models.embed_content(
                model=self.model_name,
                contents=[text],
            )
            vec = np.array(response.embeddings[0].values, dtype=np.float32)
            matrix = np.expand_dims(vec, axis=0)
            return _l2_normalize(matrix)[0]
        except Exception as e:
            print(f"[GeminiEmbeddingEngine] API call failed ({e}), falling back to local query embedder.")
            return self._fallback_local.embed_query(text)


def get_embedding_engine(provider: str = "local", api_key: Optional[str] = None) -> BaseEmbeddingEngine:
    """Factory helper to obtain the appropriate embedding engine."""
    if provider.lower() == "gemini" and api_key:
        return GeminiEmbeddingEngine(api_key=api_key)
    return LocalDenseEmbeddingEngine()
