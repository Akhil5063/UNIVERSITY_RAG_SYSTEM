"""
University Regulation RAG Assistant
Interactive Streamlit Application

Features:
- Multi-PDF upload and sample university regulations
- Page-level preprocessing and recursive chunking
- Dense vector embeddings (Gemini + Local Offline)
- FAISS & ChromaDB vector store simulation with persistence
- Metadata pre-filtering (by document and category)
- Grounded answer generation with strict refusal safeguards
- Verified document and page-level source citations
- Interactive Viva Preparation & Concepts Hub
"""

import os
import sys
import tempfile
import streamlit as st
import numpy as np

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rag.document_loader import load_multiple_pdfs, load_pdf_from_path, DocumentPage
from rag.chunker import RecursiveCharacterChunker, DocumentChunk
from rag.embeddings import get_embedding_engine, BaseEmbeddingEngine
from rag.vector_store import UniversityVectorStore
from rag.retriever import UniversityRetriever, RetrievalResult
from rag.generator import get_generator, REFUSAL_MESSAGE
from scripts.generate_sample_pdfs import create_sample_pdfs

# Streamlit Page Configuration
st.set_page_config(
    page_title="University Regulation RAG Assistant",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling for polished University UI
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #4B5563;
        margin-bottom: 1.2rem;
    }
    .badge-grounded {
        display: inline-block;
        background-color: #DEF7EC;
        color: #03543F;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .badge-refusal {
        display: inline-block;
        background-color: #FDE8E8;
        color: #9B1C1C;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .citation-card {
        background-color: #F9FAFB;
        border: 1px solid #E5E7EB;
        border-left: 4px solid #2563EB;
        border-radius: 6px;
        padding: 10px 14px;
        margin-top: 8px;
        margin-bottom: 8px;
    }
    .viva-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 16px;
    }
    .viva-title {
        color: #1E40AF;
        font-weight: 700;
        font-size: 1.15rem;
        margin-bottom: 8px;
    }
</style>
""", unsafe_allow_html=True)


# Session State Initialization
if "vector_store" not in st.session_state:
    st.session_state.vector_store = UniversityVectorStore(store_type="FAISS")
if "indexed_docs" not in st.session_state:
    st.session_state.indexed_docs = {}
if "raw_pages" not in st.session_state:
    st.session_state.raw_pages = []
if "chunks" not in st.session_state:
    st.session_state.chunks = []
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []


# Ensure sample PDFs exist
SAMPLE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "samples")
if not os.path.exists(SAMPLE_DIR) or len(os.listdir(SAMPLE_DIR)) < 4:
    try:
        create_sample_pdfs(SAMPLE_DIR)
    except Exception as e:
        st.warning(f"Note: Could not automatically generate sample PDFs: {e}")


def ingest_documents(files_to_load, chunk_size, chunk_overlap, embedding_provider, api_key, store_type):
    """Pipeline: Load PDFs -> Preprocess -> Chunk with Metadata -> Embed -> Vector Store Index."""
    with st.spinner("Processing documents, generating chunks, and computing vector embeddings..."):
        # 1. Load & Preprocess
        pages = load_multiple_pdfs(files_to_load)
        if not pages:
            st.error("No extractable text found in uploaded documents.")
            return

        st.session_state.raw_pages = pages

        # 2. Chunking with Metadata
        chunker = RecursiveCharacterChunker(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        chunks = chunker.chunk_pages(pages)
        st.session_state.chunks = chunks

        # 3. Embeddings
        embedder = get_embedding_engine(provider=embedding_provider, api_key=api_key)
        texts = [c.content for c in chunks]
        embeddings = embedder.embed_documents(texts)

        # 4. Vector Store
        vstore = UniversityVectorStore(store_type=store_type)
        vstore.add_chunks(chunks, embeddings)
        st.session_state.vector_store = vstore

        # Summary of indexed docs
        doc_stats = {}
        for p in pages:
            doc_stats[p.source] = doc_stats.get(p.source, 0) + 1
        st.session_state.indexed_docs = doc_stats

    st.success(f"Successfully indexed {len(pages)} pages across {len(doc_stats)} document(s) into {len(chunks)} chunks!")


# ==========================================
# SIDEBAR: Configurations & Ingestion
# ==========================================
with st.sidebar:
    st.title("🎓 RAG Configuration")

    st.markdown("### 1. Document Ingestion")
    uploaded_files = st.file_uploader(
        "Upload University Regulations (PDFs)",
        type=["pdf"],
        accept_multiple_files=True,
        help="Upload official university handbooks, examination codes, attendance rules, etc."
    )

    col_btn1, col_btn2 = st.columns(2)
    with col_btn1:
        load_sample = st.button("📚 Load 4 Samples", help="Loads pre-packaged official university regulation PDFs")
    with col_btn2:
        clear_store = st.button("🗑️ Clear Store", help="Reset all indexed documents")

    if clear_store:
        st.session_state.vector_store.clear()
        st.session_state.indexed_docs = {}
        st.session_state.raw_pages = []
        st.session_state.chunks = []
        st.session_state.chat_history = []
        st.info("Vector store reset.")

    st.divider()

    st.markdown("### 2. RAG Architecture Controls")
    store_type = st.selectbox(
        "Vector Store Backend",
        options=["FAISS", "ChromaDB"],
        index=0,
        help="Compare FAISS IndexFlatIP vs ChromaDB collection indexing."
    )

    embedding_provider = st.selectbox(
        "Embedding Provider",
        options=["Local Dense (Offline, Fast)", "Google Gemini Embeddings"],
        index=0,
        help="Local Dense works 100% offline without API keys; Gemini calls text-embedding-004."
    )
    provider_code = "gemini" if "Gemini" in embedding_provider else "local"

    gemini_api_key = ""
    if provider_code == "gemini" or st.checkbox("Use Gemini LLM for Generation", value=False):
        default_key = os.environ.get("GEMINI_API_KEY", "")
        gemini_api_key = st.text_input("Gemini API Key", value=default_key, type="password",
                                       help="Enter Google Gemini API Key. If empty, local grounded generator will be used.")

    st.markdown("### 3. Chunking Parameters")
    chunk_size = st.slider("Chunk Size (characters)", min_value=200, max_value=1200, value=600, step=50,
                           help="Maximum character length of each chunk.")
    chunk_overlap = st.slider("Chunk Overlap (characters)", min_value=0, max_value=300, value=100, step=25,
                             help="Overlap window to preserve cross-boundary context.")

    st.markdown("### 4. Retrieval & Grounding")
    top_k = st.slider("Top-k Chunks", min_value=1, max_value=8, value=4, step=1,
                      help="Number of nearest neighbor chunks retrieved.")
    sim_threshold = st.slider("Similarity Threshold (Cosine)", min_value=0.10, max_value=0.80, value=0.35, step=0.05,
                              help="Minimum similarity score required to accept context. Prevents hallucination on out-of-scope queries.")

    st.divider()

    st.markdown("### 5. Metadata Pre-Filtering (Viva Feature)")
    available_docs = ["All Documents"] + list(st.session_state.indexed_docs.keys())
    selected_doc = st.selectbox("Filter by Document", options=available_docs, index=0)

    available_categories = ["All Categories", "Attendance Policy", "Examination & Grading", "Academic Regulations", "Student Conduct & Handbook"]
    selected_cat = st.selectbox("Filter by Policy Category", options=available_categories, index=0)

    # Trigger Ingestion when files uploaded or button clicked
    if load_sample:
        if os.path.exists(SAMPLE_DIR):
            sample_files = [os.path.join(SAMPLE_DIR, f) for f in os.listdir(SAMPLE_DIR) if f.endswith(".pdf")]
            ingest_documents(sample_files, chunk_size, chunk_overlap, provider_code, gemini_api_key, store_type)
        else:
            st.error("Sample directory not found.")

    if uploaded_files:
        payload = []
        for uf in uploaded_files:
            payload.append((uf.getvalue(), uf.name))
        if st.button("🚀 Index Uploaded Files"):
            ingest_documents(payload, chunk_size, chunk_overlap, provider_code, gemini_api_key, store_type)

    st.markdown("---")
    st.caption("📌 **Indexed Documents Status:**")
    if st.session_state.indexed_docs:
        for doc_name, page_cnt in st.session_state.indexed_docs.items():
            st.markdown(f"- **{doc_name}** ({page_cnt} pages)")
    else:
        st.caption("No documents indexed yet. Click 'Load 4 Samples' above to start.")


# ==========================================
# MAIN APP BODY: Tabs
# ==========================================
st.markdown('<div class="main-header">🎓 University Regulation RAG Assistant</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Grounded Question Answering from University Handbooks, Academic Regulations, Examination Codes & Attendance Policies</div>', unsafe_allow_html=True)

tab_qa, tab_inspector, tab_vector, tab_viva = st.tabs([
    "💬 Ask Assistant (Q&A)",
    "📑 Document & Chunk Inspector",
    "🔍 Vector Store Explorer",
    "🎯 Viva & Technical Concepts Hub"
])


# -----------------------------------------------------------------------------
# TAB 1: ASK ASSISTANT (Q&A)
# -----------------------------------------------------------------------------
with tab_qa:
    col_main, col_sidebar_q = st.columns([3, 1])

    with col_sidebar_q:
        st.markdown("#### 💡 Sample Questions")
        sample_queries = [
            "What is the minimum attendance required to appear for exams?",
            "Can attendance between 65% and 74% be condoned and what is the fee?",
            "What is the passing score and grading scale for exams?",
            "What are the penalties for Category 2 exam malpractice?",
            "What is the maximum duration permitted to complete the B.Tech degree?",
            "What is the recipe for baking a chocolate cake?" # Test out-of-scope refusal
        ]

        for q in sample_queries:
            if st.button(q, key=f"q_btn_{hash(q)}", use_container_width=True):
                st.session_state.current_query = q

    with col_main:
        # Build metadata filter dict
        metadata_filter = {}
        if selected_doc != "All Documents":
            metadata_filter["source"] = selected_doc
        if selected_cat != "All Categories":
            metadata_filter["category"] = selected_cat

        if metadata_filter:
            st.info(f"Active Metadata Pre-Filter: `{metadata_filter}`")

        # Query Input
        default_q = st.session_state.get("current_query", "")
        user_query = st.text_input(
            "Enter your question regarding university regulations:",
            value=default_q,
            placeholder="e.g., What are the rules for medical condonation of attendance?",
            key="query_input"
        )

        submit_col1, submit_col2 = st.columns([1, 4])
        with submit_col1:
            ask_clicked = st.button("🔍 Get Answer", type="primary", use_container_width=True)

        if ask_clicked and user_query.strip():
            if len(st.session_state.vector_store.chunks) == 0:
                st.warning("⚠️ No documents indexed yet! Please load sample documents or upload PDFs in the sidebar.")
            else:
                with st.spinner("Searching vector index, evaluating threshold, and generating grounded answer..."):
                    # 1. Setup Retriever & Generator
                    embedder = get_embedding_engine(provider=provider_code, api_key=gemini_api_key)
                    retriever = UniversityRetriever(
                        vector_store=st.session_state.vector_store,
                        embedding_engine=embedder,
                        default_top_k=top_k,
                        min_similarity_threshold=sim_threshold
                    )

                    # 2. Retrieve
                    retrieval_res: RetrievalResult = retriever.retrieve(
                        query=user_query,
                        top_k=top_k,
                        metadata_filter=metadata_filter if metadata_filter else None,
                        custom_threshold=sim_threshold
                    )

                    # 3. Generate
                    gen_provider = "gemini" if (provider_code == "gemini" or gemini_api_key) else "local"
                    generator = get_generator(provider=gen_provider, api_key=gemini_api_key)
                    gen_output = generator.generate(retrieval_res)

                # Display Results
                st.markdown("### Answer")
                if gen_output["is_grounded"]:
                    st.markdown('<span class="badge-grounded">✓ Grounded in Official Documents</span>', unsafe_allow_html=True)
                    st.markdown(f"**Top Relevance Match:** `{round(retrieval_res.top_score * 100, 1)}%`")
                    st.write(gen_output["answer"])

                    # Display Source Document & Page Citations
                    st.markdown("#### 📚 Source Citations (Document & Page Numbers)")
                    if gen_output.get("citations"):
                        for cit in gen_output["citations"]:
                            st.markdown(f"""
                            <div class="citation-card">
                                <strong>📄 Document:</strong> {cit['source']} &nbsp;|&nbsp;
                                <strong>🔖 Page:</strong> {cit['page']} &nbsp;|&nbsp;
                                <strong>🏷️ Category:</strong> {cit['category']} &nbsp;|&nbsp;
                                <strong>🎯 Similarity Score:</strong> {cit['score']}%<br/>
                                <em style="color: #4B5563; font-size: 0.9rem;">"{cit['excerpt']}"</em>
                            </div>
                            """, unsafe_allow_html=True)

                    # Expandable Context Excerpts
                    with st.expander("🔬 Inspect Retrieved Context Chunks (Passed into Prompt)"):
                        for idx, (chunk, score) in enumerate(retrieval_res.chunks):
                            st.markdown(f"**Chunk #{idx+1} — [{chunk.source}, Page {chunk.page}] (Score: {round(score*100, 1)}%)**")
                            st.code(chunk.content, language="text")

                else:
                    st.markdown('<span class="badge-refusal">⚠️ Out of Domain / Not Found</span>', unsafe_allow_html=True)
                    st.error(gen_output["answer"])
                    st.info(f"**Hallucination Prevention Triggered**: The highest similarity match was `{round(retrieval_res.top_score * 100, 1)}%`, which is below your safety threshold of `{round(sim_threshold * 100, 1)}%`. To reduce hallucination, the system refused to speculate.")


# -----------------------------------------------------------------------------
# TAB 2: DOCUMENT & CHUNK INSPECTOR
# -----------------------------------------------------------------------------
with tab_inspector:
    st.markdown("### 📑 Document Loading & Chunking Inspector")
    st.markdown("Examine how documents are loaded page-by-page, cleaned, and split into overlapping chunks.")

    if not st.session_state.raw_pages:
        st.info("No documents currently loaded. Please load sample PDFs or upload files in the sidebar.")
    else:
        c1, c2, c3 = st.columns(3)
        c1.metric("Total Indexed Documents", len(st.session_state.indexed_docs))
        c2.metric("Total Extracted Pages", len(st.session_state.raw_pages))
        c3.metric("Total Generated Chunks", len(st.session_state.chunks))

        doc_names = list(st.session_state.indexed_docs.keys())
        selected_inspect_doc = st.selectbox("Select Document to Inspect", options=doc_names)

        doc_pages = [p for p in st.session_state.raw_pages if p.source == selected_inspect_doc]
        doc_chunks = [c for c in st.session_state.chunks if c.source == selected_inspect_doc]

        st.markdown(f"#### Pages in `{selected_inspect_doc}` ({len(doc_pages)} Pages)")
        page_nums = [p.page_number for p in doc_pages]
        selected_page_num = st.select_slider("Select Page Number", options=page_nums)

        chosen_page = next((p for p in doc_pages if p.page_number == selected_page_num), None)
        if chosen_page:
            st.markdown(f"**Page {chosen_page.page_number} Content (Character Count: {len(chosen_page.content)})**")
            st.text_area("Extracted & Preprocessed Page Text", chosen_page.content, height=180)

            # Chunks for this specific page
            page_chunks = [c for c in doc_chunks if c.page == selected_page_num]
            st.markdown(f"##### Generated Chunks for Page {selected_page_num} ({len(page_chunks)} chunks)")
            for ch in page_chunks:
                with st.expander(f"Chunk ID: `{ch.chunk_id}` ({ch.char_count} chars)"):
                    st.text(ch.content)


# -----------------------------------------------------------------------------
# TAB 3: VECTOR STORE EXPLORER
# -----------------------------------------------------------------------------
with tab_vector:
    st.markdown("### 🔍 Vector Store Explorer (FAISS / ChromaDB)")
    st.markdown("Explore the underlying vector space, stored embeddings, and test raw similarity queries.")

    vstore = st.session_state.vector_store
    if vstore.vectors is None or len(vstore.chunks) == 0:
        st.info("Vector store is currently empty.")
    else:
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Store Backend", vstore.store_type)
        m2.metric("Total Vectors Indexed", len(vstore.vectors))
        m3.metric("Vector Dimension", vstore.dimension)
        m4.metric("Memory Footprint", f"{round(vstore.vectors.nbytes / 1024, 2)} KB")

        st.divider()

        st.markdown("#### 🧪 Interactive Vector Search Simulator")
        test_query = st.text_input("Test Query Vector Search:", value="attendance shortage medical condonation")
        test_k = st.slider("Test Top-k", min_value=1, max_value=6, value=3)

        if st.button("Run Vector Distance Search"):
            embedder = get_embedding_engine(provider=provider_code, api_key=gemini_api_key)
            q_vec = embedder.embed_query(test_query)
            scored = vstore.similarity_search(q_vec, top_k=test_k)

            st.write(f"Search Results for: *'{test_query}'*")
            for i, (chunk, score) in enumerate(scored):
                st.markdown(f"**Rank #{i+1}** | **Cosine Similarity:** `{round(score, 4)}` ({round(score*100, 1)}%) | Source: `{chunk.source}` (Page {chunk.page})")
                st.info(f'"{chunk.content}"')


# -----------------------------------------------------------------------------
# TAB 4: VIVA & TECHNICAL CONCEPTS HUB
# -----------------------------------------------------------------------------
with tab_viva:
    st.markdown("### 🎯 Viva Voce & Technical Concepts Hub")
    st.markdown("Comprehensive academic and practical guide on the core pillars of Retrieval-Augmented Generation (RAG).")

    viva_col1, viva_col2 = st.columns(2)

    with viva_col1:
        # 1. Chunking
        st.markdown("""
        <div class="viva-card">
            <div class="viva-title">1. Document Chunking & Strategy</div>
            <strong>Why Chunking?</strong>
            LLMs have finite context windows, and embedding a 50-page document as a single vector averages out granular details. Chunking isolates specific regulatory clauses.
            <br/><br/>
            <strong>Recursive Character Text Splitting:</strong>
            Unlike fixed token splitting, recursive splitting respects natural language hierarchies: paragraphs (<code>\\n\\n</code>) -> sentences (<code>. </code>) -> words (<code> </code>). This ensures whole rules and penalties stay intact.
            <br/><br/>
            <strong>The Role of Chunk Overlap:</strong>
            Chunk overlap (e.g., 100 characters) prevents "boundary amnesia". When a regulation specifies a condition in one sentence and a deadline/fee in the next, overlap ensures both appear in at least one shared chunk.
        </div>
        """, unsafe_allow_html=True)

        # 3. Vector Search
        st.markdown("""
        <div class="viva-card">
            <div class="viva-title">3. Vector Search Mechanics</div>
            <strong>Exact Search vs ANN:</strong>
            <ul>
                <li><strong>IndexFlatIP / IndexFlatL2 (Exact):</strong> Computes dot product across all vectors. Complexity is <em>O(N)</em>. 100% accurate, optimal for small-to-medium institutional corpuses.</li>
                <li><strong>HNSW / IVF (Approximate Nearest Neighbor):</strong> Uses graph navigation or inverted clusters to achieve <em>O(log N)</em> sub-linear search on millions of documents at the expense of slight recall loss.</li>
            </ul>
            <strong>Similarity Metric:</strong>
            Cosine similarity measures the angle between query and document vectors, independent of vector magnitude:
            <br/>
            $$\\text{Cosine}(\\vec{q}, \\vec{d}) = \\frac{\\vec{q} \\cdot \\vec{d}}{\\|\\vec{q}\\|_2 \\|\\vec{d}\\|_2}$$
        </div>
        """, unsafe_allow_html=True)

        # 5. Metadata Filtering
        st.markdown("""
        <div class="viva-card">
            <div class="viva-title">5. Metadata Filtering</div>
            <strong>Pre-filtering vs Post-filtering:</strong>
            <ul>
                <li><strong>Pre-filtering (Implemented):</strong> Restricts vector search only to chunks satisfying metadata attributes (e.g. <code>source == 'Attendance_Policy.pdf'</code>). Eliminates false positive matches from unrelated regulations.</li>
                <li><strong>Post-filtering:</strong> Retrieves top-<em>k</em> globally, then discards non-matching chunks, which risks returning fewer than <em>k</em> valid results.</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

    with viva_col2:
        # 2. Embeddings
        st.markdown("""
        <div class="viva-card">
            <div class="viva-title">2. Dense Vector Embeddings</div>
            <strong>Representation:</strong>
            Text is projected into a continuous <em>D</em>-dimensional vector space (e.g., 384 or 768 dimensions). Words with similar semantic intent are positioned close to each other.
            <br/><br/>
            <strong>Semantic Proximity over Lexical Matching:</strong>
            A keyword search for <em>"missing classes"</em> fails if the document says <em>"attendance shortage"</em>. Dense embeddings map both phrases to the same geometric neighborhood.
            <br/><br/>
            <strong>L2 Normalization:</strong>
            By normalizing vectors to unit length ($\\|\\vec{v}\\|_2 = 1$), Euclidean distance and Cosine similarity become mathematically equivalent, and cosine similarity simplifies to a single fast dot product.
        </div>
        """, unsafe_allow_html=True)

        # 4. Hallucination Reduction
        st.markdown("""
        <div class="viva-card">
            <div class="viva-title">4. Hallucination Reduction (Multi-Tier Defense)</div>
            <strong>Tier 1: Algorithmic Distance Cutoff</strong>
            If the highest similarity score is below the threshold (e.g. &lt; 0.35), the query is out-of-domain. The system refrains from calling the generator and returns a refusal immediately.
            <br/><br/>
            <strong>Tier 2: Strict System Prompting</strong>
            Explicit negative constraint instructs the LLM: <em>"Answer ONLY using the provided excerpts. If the facts are not present, output the standard refusal message."</em>
            <br/><br/>
            <strong>Tier 3: Verified Source Citations</strong>
            Every claim is accompanied by bracketed document and page citations (e.g. <code>[Attendance_Policy.pdf, Page 2]</code>), allowing instant human verification against the source text.
            <br/><br/>
            <strong>Tier 4: Low Temperature</strong>
            Setting <code>temperature=0.1</code> suppresses stochastic creative sampling, forcing deterministic factual recall.
        </div>
        """, unsafe_allow_html=True)
