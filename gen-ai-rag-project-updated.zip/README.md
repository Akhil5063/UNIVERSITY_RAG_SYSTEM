# 🎓 University Regulation RAG Assistant

A production-grade, Retrieval-Augmented Generation (RAG) system specialized in querying university academic regulations, examination guidelines, attendance policies, and student handbooks.

Built for **compliance accuracy**, **zero-hallucination guarantees**, and **viva voce evaluation**.

---

## 🚀 Key Features

1. **Multi-PDF Document Ingestion**:
   - Ingest multiple PDF documents (Academic Rules, Exam Codes, Attendance Policies, Student Handbooks).
   - Page-by-page text extraction and cleaning with strict preservation of document name, page number, and policy category.

2. **Recursive Character Chunking**:
   - Hierarchical splitting respecting natural semantic boundaries: Paragraphs (`\n\n`) $\rightarrow$ Lines (`\n`) $\rightarrow$ Sentences (`. `) $\rightarrow$ Words (` `).
   - Configurable chunk size (default 600 chars) and overlap (default 100 chars) preventing boundary context loss.

3. **Dual Embedding Modes**:
   - **Google Gemini Embeddings**: Semantic embeddings using `text-embedding-004` (768 dimensions).
   - **Local Dense Semantic Vectorizer**: 100% offline, zero-dependency normalized dense vectorizer (384 dimensions) with subword n-gram hashing and IDF weighting.

4. **Vector Store & Indexing**:
   - Dual support for **FAISS** (IndexFlatIP) and **ChromaDB** collection structures.
   - Vector L2 normalization ensuring inner product equals exact cosine similarity.
   - Index persistence to disk (`.cache/vector_store/`).

5. **Metadata Pre-Filtering (Viva Focus)**:
   - Restrict retrieval to specific regulations (e.g. only search `Attendance Policy` or `Student_Code_of_Conduct.pdf`).
   - Prevents cross-regulation contamination and reduces candidate search space.

6. **Strict Hallucination Reduction**:
   - **Confidence Gating**: If the top similarity score is below the cutoff threshold (e.g. 0.35), the system immediately refuses without calling the LLM.
   - **Negative Grounding Constraint**: Prompt strictly prohibits assuming or speculating outside context.
   - **Standard Refusal Message**: *"I cannot find the answer to this question in the provided university regulations and documents."*
   - **Low Temperature**: Set to 0.1 for maximum factual determinism.

7. **Verified Source Citations**:
   - Every grounded answer is attributed to the exact `[Document Name, Page Number]`.
   - Interactive UI displays relevance percentage match and expandable context excerpts.

8. **Interactive Streamlit Dashboard**:
   - **Tab 1: Ask Assistant**: Interactive Q&A with sample queries, relevance meters, and citations.
   - **Tab 2: Document Inspector**: View extracted text, page numbers, and chunk boundaries.
   - **Tab 3: Vector Store Explorer**: Inspect vector dimensions, memory footprint, and test similarity distances.
   - **Tab 4: Viva Voce & Technical Guide**: In-depth explanations of Chunking, Embeddings, Vector Search (Exact vs ANN), Hallucination Reduction, and Metadata Filtering.

---

## 📂 Project Architecture

```
gen-ai/
├── app.py                          # Interactive Streamlit Web Application
├── requirements.txt                # Project dependencies
├── rag/                            # Core RAG Engine
│   ├── __init__.py
│   ├── document_loader.py          # PDF loader, preprocessor & metadata extractor
│   ├── chunker.py                  # Recursive Character Splitter with overlap
│   ├── embeddings.py               # Gemini & Local Dense Embedding engines
│   ├── vector_store.py             # FAISS / ChromaDB vector stores with persistence
│   ├── retriever.py                # Retrieval engine with similarity thresholding
│   └── generator.py                # Grounded synthesis with refusal & citations
├── scripts/
│   ├── __init__.py
│   └── generate_sample_pdfs.py     # Generates 4 realistic university regulation PDFs
├── data/
│   └── samples/                    # Pre-packaged sample university regulation PDFs
│       ├── Academic_Regulations_2026.pdf
│       ├── Attendance_Policy.pdf
│       ├── Examination_Guidelines.pdf
│       └── Student_Code_of_Conduct.pdf
└── tests/
    ├── __init__.py
    └── test_rag.py                 # Automated test suite (8 unit & integration tests)
```

---

## 🛠️ Quick Start & Setup

### 1. Activate Environment
```bash
.\.venv\Scripts\Activate.ps1
```

### 2. Generate Sample PDFs
```bash
python scripts/generate_sample_pdfs.py
```

### 3. Run Automated Tests
```bash
python -m unittest discover tests
```

### 4. Launch the Web Application
```bash
streamlit run app.py
```

---

## 🎯 Viva Voce Revision Sheet

| Concept | Explanation | Why It Matters in this Project |
|---|---|---|
| **Chunking** | Splitting text into fixed/variable passages with overlap | Preserves regulation rules without exceeding embedding model context windows or diluting facts |
| **Chunk Overlap** | Re-including trailing tokens of chunk $i$ in chunk $i+1$ | Prevents "boundary amnesia" where a condition and its penalty get split across two chunks |
| **Dense Embeddings** | Continuous vector representations of semantic meaning | Matches conceptual intent (e.g. *"missing classes"* $\rightarrow$ *"attendance shortage"*) unlike keyword search |
| **Vector Search** | Finding top-$k$ nearest neighbors in vector space | Fast similarity ranking using Cosine Similarity / Inner Product: $\frac{\vec{q} \cdot \vec{d}}{\|\vec{q}\|_2 \|\vec{d}\|_2}$ |
| **Metadata Filtering** | Restricting search space by document or category | Eliminates false matches (e.g., searching for exam fees won't pull attendance fees) |
| **Hallucination Reduction** | Multi-tier defense (distance cutoff + negative prompt + citations) | Guarantees the assistant says *"I cannot find the answer"* when a query is out-of-domain |
